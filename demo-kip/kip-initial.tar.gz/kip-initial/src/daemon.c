/* KIP Service daemon, main program.
 *
 * The KIP Service is very much a "remote keytab" that unpacks keys
 * as directed by the ACL that is packed along with them.  When the
 * KIP library calls kipkey_fromservice() or kipkey_toservice() are
 * called they will connect to a KIP Service to get some work done,
 * but always just on the keys and never on the data
 *
 * From: Rick van Rein <rick@openfortress.nl>
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <krb5.h>
#include <arpa2/kip.h>

#include "socket.h"



char *test_ktfilenm = NULL;
char *test_ktdomain = NULL;

struct mappingpair { uint32_t kvno; int32_t enctype; };



#if 0
void print_block (char *descr, uint8_t *blk, uint32_t blklen, bool skip) {
	int i;
	printf ("%s =", descr);
	for (i=0; i<blklen; i++) {
		printf (" %02x", blk [i]);
		if (skip && (i > 5) && (i < blklen - 5)) {
			printf (" ...");
			i = blklen - 5;
		}
	}
	printf (" -> #%d\n", blklen);
}
#endif


bool process_toservice (kipt_ctx kip, int cnx, uint8_t *plain, uint32_t plainlen) {
	//
	// Basic sanity checking -- TODO: due to static allocation, can be improved
	uint8_t crypt [32768];
	uint8_t *out_crypt = crypt;
	uint32_t cryptlen = sizeof (crypt);
	if ((plainlen < 10) || (plainlen > cryptlen)) {
		errno = EINVAL;
		return false;
	}
	//
	//TODO// Sanity check: plain is (kvno,alg) + raw key data for alg
	//
	// Retrieve the keymap entry belonging to the key in the keymsg
	// (Use 0 for keynr and alg to get whatever the keytab suggests)
	kipt_keyid keyid;
	if (!kipkey_fromkeytab (kip, test_ktfilenm, NULL, test_ktdomain, 0, 0, &keyid)) {
		return false;
	}
	kipt_keynr keynr = (krb5_kvno) keyid;	/* Trim down to wire size */
	kipt_alg   alg;
	if (!kipkey_algorithm (kip, keyid, &alg)) {
		return false;
	}
	//
	// Setup _fromservice() preamble with the (keynr,alg) from the keytab
	struct mappingpair *pair = (struct mappingpair *) crypt;
	pair->kvno    = htonl( keynr );
	pair->enctype = htonl( alg   );
	//
	// Encrypt the message remainder with the keyid from the keytab
	if (!kipservice_dress (kip, keyid, plainlen, plain,
				cryptlen - 8, out_crypt + 8, &cryptlen)) {
		goto zap_fail;
	}
	cryptlen += 8;
	//
	// Send out the cipertext
	ssize_t sent = send (cnx, out_crypt, cryptlen, MSG_NOSIGNAL);
	if (sent <= 0) {
		if (sent == 0) {
			errno = ECONNRESET;
		}
		goto zap_fail;
	} else if (sent != cryptlen) {
		errno = ECOMM;
		goto zap_fail;
	}
	//
	// Return success
	return true;
zap_fail:
	memset (crypt, 0, sizeof (crypt));	/* never ever leak memory */
	return false;
}


bool process_fromservice (kipt_ctx kip, int cnx, uint8_t *crypt, uint32_t cryptlen) {
	//
	// Basic sanity checking -- TODO: due to static allocation, can be improved
	uint8_t plain [32768];
	uint32_t plainlen = sizeof (plain);
	if ((cryptlen < 10) || (cryptlen > plainlen)) {
		return false;
	}
	//
	// Retrieve the keynr/alg from the preamble to the encrypted message
	struct mappingpair *pair = (struct mappingpair *) crypt;
	crypt    += 8;
	cryptlen -= 8;
	kipt_keynr keynr = ntohl( pair->kvno    );
	kipt_alg   alg   = ntohl( pair->enctype );
	//
	// Retrieve the keymap entry belonging to the keynr/alg in the preamble
	kipt_keyid keyid;
	if (!kipkey_fromkeytab (kip, test_ktfilenm, NULL, test_ktdomain, keynr, alg, &keyid)) {
		return false;
	}
	//
	// Decrypt the message remainder with the keyid from the keytab
	if (!kipservice_strip (kip, keyid, cryptlen, crypt,
				plainlen, plain, &plainlen)) {
		goto zap_fail;
	}
	//
	// Send out the plaintext -- starting with keynr/alg in client context
	ssize_t sent = send (cnx, plain, plainlen, MSG_NOSIGNAL);
	if (sent <= 0) {
		if (sent == 0) {
			errno = ECONNRESET;
		}
		goto zap_fail;
	} else if (sent != plainlen) {
		errno = ECOMM;
		goto zap_fail;
	}
	//
	// Return success
	return true;
	//
	// Cleanup and return error
zap_fail:
	memset (plain, 0, sizeof (plain));	/* never ever leak */
	return false;
}


void process_commands (int cnx, char *domain) {
	//
	// Open a KIP context
	kipt_ctx kip;
	if (!kipctx_open (&kip)) {
		goto fail;
	}
	//
	// The main loop will read 1-byte commands followed by a larger blob
	char cmd;
	while (recv (cnx, &cmd, 1, MSG_NOSIGNAL) == 1) {
		//
		// Read the command code -- TODO: Move to the splendour of DER
		if ((cmd != '?') && (cmd != '!')) {
			fprintf (stderr, "Illegal command '%c' in simplistic protocol\n", cmd);
			break;
		}
		//
		// Read the followup keyful message -- TODO: Move it into DER
		uint8_t keybuf [2048];
		ssize_t recvd = recv (cnx, keybuf, sizeof (keybuf), MSG_NOSIGNAL);
		if (recvd > sizeof (keybuf)) {
			errno = ENOBUFS;
			recvd = -1;
		}
		if (recvd <= 0) {
			if (recvd == 0) {
				errno = ECONNRESET;
			}
			perror ("Command reading failed");
		}
		uint32_t keybuflen = (uint32_t) recvd;
		//
		// Process the command
		switch (cmd) {
		case '?':
			if (!process_fromservice (kip, cnx, keybuf, keybuflen)) {
				perror ("Failure while recovering key");
				goto ctx_fail;
			}
			break;
		case '!':
			if (!process_toservice   (kip, cnx, keybuf, keybuflen)) {
				perror ("Failure while concealing key");
				goto ctx_fail;
			}
			break;
		default:
			assert ((cmd == '?') || (cmd == '!'));
		}
	}
ctx_fail:
	kipctx_close (kip);
fail:
	return;
}


void please_stop (int stopsignal) {
	printf ("Exiting gently on stop signal\n");
	exit (0);
}


int main (int argc, char *argv []) {
	//
	// Check the commandline
	if (argc != 6) {
		fprintf (stderr, "Usage: %s <address> <port> <keytabfile> <keytabdomain> <stopsig>\n", argv [0]);
		exit (1);
	}
	char *progname = argv [0];
	char *hostname = argv [1];
	char *portname = argv [2];
	test_ktfilenm  = argv [3];
	test_ktdomain  = argv [4];
	int stopsignal = atoi (argv [5]);
	//
	// Install the stop signal handler
	signal (stopsignal, please_stop);
	//
	// Get a server socket
	struct sockaddr_storage sa;
	if (!socket_parse (hostname, portname, (struct sockaddr *) &sa)) {
		com_err (progname, errno, "Failed to parse host:name from %s:%s\n", hostname, portname);
		exit (1);
	}
	int sox = -1;
reconnect:
	if (!socket_server ((const struct sockaddr *) &sa, SOCK_STREAM, &sox)) {
		com_err (progname, errno, "Failed to serve on %s port %s\n", hostname, portname);
#if 0
		if (errno == EADDRINUSE) {
			sleep (5);
			goto reconnect;
		}
#endif
		exit (1);
	}
	//
	// Report to Pypeline that we are ready for action
	printf ("--\n");
	fflush (stdout);
	//
	// Main "loop", waiting for a connection (for now: one at a time)
	struct sockaddr_storage peer;
	socklen_t peerlen = sizeof (peer);
	int cnx = -1;
	while ( (cnx = accept (sox, (struct sockaddr *) &peer, &peerlen)) ) {
		if (cnx < 0) {
			fprintf (stderr, "Failed to pickup incoming connection\n");
			continue;
		}
		fprintf (stderr, "Serving SIMPLISTIC PROTOCOL which is due to CHANGE WITHOUT NOTICE\n");
		//
		//TODO// Switch to TLS over this connection
		//
		//TODO// Run a SASL handshake over this connection
		//
		// Handle the connection
		process_commands (cnx, "unicorn.demo.arpa2.org");
		close (cnx);
	}
	//
	// Cleanup and close without error
	close (sox);
	return 0;
}
