/* libkip.c -- Common routines for the Keyful Identity Protocol
 *
 * This library implements the routines defined in <arpa2/kip.h>
 * to manage keys.  It uses MIT krb5 as its underlying library,
 * but the other Kerberos variants would work too.  There is
 * no other need than the crypto code; the entire framework of
 * KDC interaction is not needed.
 *
 * The reason to use Kerberos directly, rather than the higher
 * level GSS-API that is commonly advised, is that the latter
 * requires a protocol to establish its context.  The uses of
 * libkip are not shaped like that.
 *
 * From: Rick van Rein <rick@openfortress.nl>
 */


#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

/* Hash functions from OpenSSL:
 * https://www.openssl.org/docs/man1.1.0/man3/SHA1.html
 */
#include <openssl/sha.h>

#include <unbound.h>

#include <errno.h>
#include <com_err.h>
#include <kiperr.h>

#include <krb5.h>

#include <arpa2/kip.h>
#include "utlist.h"


/* Identifiers are 64-bit and somewhat ordered by the top 32-bits:
 *  - Value 0 is for key numbers (wire format keys)
 *  - Values 1 to 0x7fffffff are added to keyids to make them unique
 *  - Values 0x80000000 to 0xffffffff are unique sum identities
 *
 * We are lazy.  Assuming that no context will have more than
 * 2147483647 keys and dito checksums over their complete life.
 * Since the average context exists only to work on a document, even
 * if it is to edit one, it should be no problem to assume this.
 *
 * So, we will simply increment a unique number for each key and
 * checksum that the user adds, and use that on top.  We just need
 * to flip the sign for sums that are not implicit for a key.  It
 * is quite simply the most efficient, and seems practical.
 */


typedef struct kip_sum {
	//
	// The list key and links
	kipt_sumid sumid;
	struct kip_sum *next;
	//
	// Storage depends on the hash type
	kipt_alg keyalg;
	kipt_keyid keyid;
	union {
		SHA_CTX sha1;
		SHA256_CTX sha256;
		SHA512_CTX sha384;	/* SHA384 is a prefix of SHA512 with its own init */
		SHA512_CTX sha512;
	} hctx;
} kipt_sum;


typedef struct kip_key {
	//
	// The list key and links
	kipt_keyid keyid;
	struct kip_key *next;
	//
	// The krb5 key structure
	krb5_keyblock k5keyblk;
	//
	// The checksum for this key
	kipt_sum keysum;
} kipt_key;


typedef struct kipt_context {
	// Underlying MIT krb5 context
	krb5_context k5ctx;
	// Underlying Unbound context
	struct ub_ctx *ubctx;
	// Lists of inserted data
	struct kip_key *keys_head;
	struct kip_sum *sums_head;
	// Unique counter, lazily used for keys and checksums
	uint32_t uniqtr;
	// Cached socket, uplink to the KIP Service
	int service_uplink;
} *kipt_ctx;


static bool _hash_init   (kipt_sum *sum, kipt_key *keyalg);
static bool _hash_update (kipt_sum *sum, uint8_t *data, uint32_t datalen);

#define zap_free(m) { memset ((m), 0, sizeof (*(m))); free ((m)); }


// Internal algorithm code, from the local range, indicating anything
#define _KIP_ALG_ANY 0xcf2bd9aa



/* Open a context for kipping up and/or down.  You can use different
 * contexts for the kip up and kip down processes.  The context is
 * a place in which to mount keys and checksums.  Once done, the
 * contents may be eradicated.
 */
bool kipctx_open (kipt_ctx *out_ctx) {
	//
	// Allocate the data structure, filled with zeroes
	kipt_ctx ctx = calloc (1, sizeof (struct kipt_context));
	if (ctx == NULL) {
		errno = ENOMEM;
		goto fail;
	}
	//
	// The lists must be cleared, which calloc() did for us.
	;
	//
	// Initialise the fields
	krb5_error_code k5err = 0;
	k5err = krb5_init_context (&ctx->k5ctx);
	if (k5err != 0) {
		errno = k5err;
		goto free_fail;
	}
	ctx->service_uplink = -1;
	//
	// Return the new management structure
	*out_ctx = ctx;
	return true;
	//
	// Cleanup and fail
free_fail:
	zap_free (ctx);
fail:
	return false;
}


/* Close a context for kip, destroying all the resources that were
 * allocated to it.  Any key material is first overwritten with
 * zeroes before it is removed.
 */
void kipctx_close (kipt_ctx ctx) {
	assert (ctx != NULL);
	kipt_key *key, *tmp;
	LL_FOREACH_SAFE (ctx->keys_head, key, tmp) {
		// Allocated after the key, zap it but don't free
		memset (key->k5keyblk.contents, 0, key->k5keyblk.length);
		zap_free (key);
	}
	krb5_free_context (ctx->k5ctx);
	if (ctx->service_uplink >= 0) {
		close (ctx->service_uplink);
	}
	if (ctx->ubctx) {
		ub_ctx_delete (ctx->ubctx);
	}
	zap_free (ctx);
}


/* Produce random bytes with the given address and length.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 */
bool kipdata_random (kipt_ctx ctx, uint32_t len_target, uint8_t *out_target) {
	krb5_data ktgt;
	ktgt.length = len_target;
	ktgt.data   = out_target;
	krb5_error_code k5err;
	k5err = krb5_c_random_make_octets (ctx->k5ctx, &ktgt);
	if (k5err != 0) {
		errno = k5err;
		return false;
	} else {
		return true;
	}
}


/* Given a KIP key, determine its algorithm.
 */
bool kipkey_algorithm (kipt_ctx ctx, kipt_keyid keyid,
			kipt_alg *out_alg) {
	//
	// Find the key to conceal
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, keyid);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Return success
	*out_alg = kk->k5keyblk.enctype;
	return true;
	//
	// Return failure
fail:
	return false;
}



/* Encrypt or *kip up* a clear text string into a bucket of mud.
 * The routine encrypts a block of clear text in isolation; your
 * application may however develop a system that splits content
 * into blocks of a moderate size and treat those separately.
 *
 * When your application splits data into blocks, the entirety
 * of the transported information is not protected by a sequence
 * of kipdata_up() calls.  The suggested remedy is to have an overall
 * checksum under protection of each key.  You can feed data into
 * the checksum with the routines below.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 *
 * If the max_mudsz is too low, this function sets KIPERR_OUTPUT_SIZE
 * and nothing will get written to mud, not even a NULL value would
 * be noticed.  The out_mudsz value will be filled, though, and you
 * can use this to measure the desired output size.  When you set
 * max_mudsz=0 you can trigger this deliberately.
 */
bool kipdata_up (kipt_ctx ctx, kipt_keyid key,
			uint8_t *clear,   uint32_t clearsz,    /* input  */
			uint8_t *out_mud, uint32_t max_mudsz,  /* outbuf */
			uint32_t *out_mudsz) {                 /* usedup */
	//
	// Find the key to conceal
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, key);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Check if we have sufficient room for output
	krb5_error_code k5err = 0;
	size_t needlen = ~0;
	k5err = krb5_c_encrypt_length (ctx->k5ctx, kk->k5keyblk.enctype, clearsz, &needlen);
	if (k5err != 0) {
		errno = k5err;
		goto fail;
	}
	if ((needlen >> 32) != 0) {
		errno = ERANGE;
		goto fail;
	}
	*out_mudsz = (uint32_t) needlen;
	if (needlen > max_mudsz) {
		errno = KIPERR_OUTPUT_SIZE;
		goto fail;
	}
	//
	// Actually encrypt
	krb5_data     plain;
	krb5_enc_data crypt;
	plain.data   = clear;
	plain.length = clearsz;
	crypt.kvno    = (krb5_kvno) key;	/* cut down to wire size */
	crypt.enctype = kk->k5keyblk.enctype;
	crypt.ciphertext.data   = out_mud;
	crypt.ciphertext.length = max_mudsz;
	k5err = krb5_c_encrypt (ctx->k5ctx, &kk->k5keyblk, KIP_KEYUSAGE_USERDATA,
			NULL, &plain, &crypt);
	if (k5err != 0) {
		errno = k5err;
		goto wipe_fail;
	}
	//
	// Update the key-implied hash with the data before encryption
	_hash_update (&kk->keysum, clear, clearsz);
	//
	// Return success
	*out_mudsz = crypt.ciphertext.length;
	return true;
	//
	// Cleanup and return failure
wipe_fail:
	memset (out_mud, 0, max_mudsz);  /* Never ever leak */
	*out_mudsz = 0;
fail:
	return false;
}



static bool _loop_decrypt (kipt_ctx ctx, krb5_keyusage keyusage,
				kipt_keyid key_id_nr, kipt_alg enctype,
				kipt_key **actual_key,
				uint8_t *cur_data, uint32_t  cur_len,
				uint8_t *nxt_data, uint32_t *nxt_len) {
	//
	// Pass through all keys for usable ones
	kipt_key *curkey;
	bool done = false;
	uint64_t mask = ~0L;
	if (key_id_nr < 4294967296L) {
		mask = 0xffffffffL;
	}
	LL_FOREACH (ctx->keys_head, curkey) {
		if (key_id_nr != (curkey->keyid & mask)) {
			continue;
		}
		if (enctype != curkey->k5keyblk.enctype) {
			if (enctype != _KIP_ALG_ANY) {
				continue;
			}
		}
		//
		// Just _try_ the key (partial identity!)
		krb5_error_code k5err = 0;
		krb5_enc_data crypt;
		krb5_data     plain;
		crypt.kvno    = (krb5_kvno) key_id_nr;
		crypt.enctype = curkey->k5keyblk.enctype;
		crypt.ciphertext.data   = cur_data;
		crypt.ciphertext.length = cur_len;
		plain.data   = nxt_data;
		plain.length = cur_len;
		k5err = krb5_c_decrypt (ctx->k5ctx, &curkey->k5keyblk, keyusage,
				NULL, &crypt, &plain);
		if (k5err == 0) {
			//
			// We were successful
			if (actual_key != NULL) {
				*actual_key = curkey;
			}
			cur_data = plain.data;
			*nxt_len = plain.length;
			return true;
		}
	}
	//
	// Finished, and no key caught our imagination
	return false;
}


static void _nokey_errno (kipt_keyid id_or_nr) {
	if (id_or_nr < 4294967296L) {
		errno = KIPERR_NO_MATCHING_KEY;
	} else {
		errno = KIPERR_KEYID_NOT_FOUND;
	}
}



/* Decrypt or *kip down* a bucket of mud into a clear text string.
 * The routine decrypts a bucket of mud in isolation, and always
 * as a whole; the application may however compose multiple of
 * these buckets in some way.  See kipdata_up() for how this is done,
 * and be sure to validate the checksums it generates to retain
 * consistency.
 *
 * The key may be a unique key identity or the key number hints 
 * that form a subset thereof; hints may require a few passes
 * through the decryption process though, in case of clashes
 * of those key numbers.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 *
 * If the max_clearsz is too low, this function sets
 * KIPERR_OUTPUT_SIZE and nothing will get written to clean, not
 * even a NULL value would be noticed.  The out_clearsz value will
 * be filled though, and you can use this to measure the desired
 * output size.  When you set max_clearsz=0 you can trigger this
 * deliberately.
 */
bool kipdata_down (kipt_ctx ctx, kipt_keyid key_id_nr,
			uint8_t *mud,       uint32_t mudsz,        /* input  */
			uint8_t *out_clear, uint32_t max_clearsz,  /* outbuf */
			uint32_t *out_clearsz) {                   /* usedup */
	//
	// Check if we have enough space for the output
	*out_clearsz = mudsz;
	if (max_clearsz < mudsz) {
		/* Too cautious, but how can we calc it? */
		errno = KIPERR_OUTPUT_SIZE;
		goto fail;
	}
	//
	//
	// Actually decrypt -- allow key numbers via looped matching
	uint32_t clearlen = 0;
	kipt_key *actual_key;
	bool done = _loop_decrypt (ctx, KIP_KEYUSAGE_USERDATA,
				key_id_nr, _KIP_ALG_ANY,
				&actual_key,
				mud, mudsz,
				out_clear, &clearlen);
	if (!done) {
		_nokey_errno (key_id_nr);
		goto wipe_fail;
	}
	//
	// Update the key-implied hash with the data after decryption
	_hash_update (&actual_key->keysum, out_clear, clearlen);
	//
	// Return success
	*out_clearsz = clearlen;
	return true;
wipe_fail:
	memset (out_clear, 0, max_clearsz);	/* Never ever leak */
fail:
	return false;
}


#define _KIP_ALG_LAST 26
static int _enctype_acceptance [_KIP_ALG_LAST+1] = {
	KIPERR_ALGORITHM_UNKNOWN,	// 0    reserved    [RFC6448]
	KIPERR_ALGORITHM_DEPRECATED,	// 1    des-cbc-crc (deprecated)    [RFC6649]
	KIPERR_ALGORITHM_DEPRECATED,	// 2    des-cbc-md4 (deprecated)    [RFC6649]
	KIPERR_ALGORITHM_DEPRECATED,	// 3    des-cbc-md5 (deprecated)    [RFC6649]
	KIPERR_ALGORITHM_UNKNOWN,	// 4    Reserved    [RFC3961]
	KIPERR_ALGORITHM_DEPRECATED,	// 5    des3-cbc-md5 (deprecated)    [RFC8429]
	KIPERR_ALGORITHM_UNKNOWN,	// 6    Reserved    [RFC3961]
	KIPERR_ALGORITHM_DEPRECATED,	// 7    des3-cbc-sha1 (deprecated)    [RFC8429]
	KIPERR_ALGORITHM_UNKNOWN,	// 8    Unassigned    
	KIPERR_ALGORITHM_PURPOSE,	// 9    dsaWithSHA1-CmsOID    [RFC4556]
	KIPERR_ALGORITHM_PURPOSE,	// 10    md5WithRSAEncryption-CmsOID    [RFC4556]
	KIPERR_ALGORITHM_PURPOSE,	// 11    sha1WithRSAEncryption-CmsOID    [RFC4556]
	KIPERR_ALGORITHM_PURPOSE,	// 12    rc2CBC-EnvOID    [RFC4556]
	KIPERR_ALGORITHM_PURPOSE,	// 13    rsaEncryption-EnvOID    [RFC4556][from PKCS#1 v1.5]]
	KIPERR_ALGORITHM_PURPOSE,	// 14    rsaES-OAEP-ENV-OID    [RFC4556][from PKCS#1 v2.0]]
	KIPERR_ALGORITHM_DEPRECATED,	// 15    des-ede3-cbc-Env-OID    [RFC4556]
					// (DES-EDE is locally deprecated)
	KIPERR_ALGORITHM_DEPRECATED,	// 16    des3-cbc-sha1-kd (deprecated)    [RFC8429]
	0,				// 17    aes128-cts-hmac-sha1-96    [RFC3962]
	0,				// 18    aes256-cts-hmac-sha1-96    [RFC3962]
	0,				// 19    aes128-cts-hmac-sha256-128    [RFC8009]
	0,				// 20    aes256-cts-hmac-sha384-192    [RFC8009]
	KIPERR_ALGORITHM_UNKNOWN,
	KIPERR_ALGORITHM_UNKNOWN,	// 21-22    Unassigned    
	KIPERR_ALGORITHM_DEPRECATED,	// 23    rc4-hmac (deprecated)    [RFC8429]
	KIPERR_ALGORITHM_DEPRECATED,	// 24    rc4-hmac-exp (deprecated)    [RFC6649]
	0,				// 25    camellia128-cts-cmac    [RFC6803]
	0,				// 26    camellia256-cts-cmac    [RFC6803]
};


static bool _newkey (kipt_ctx ctx, kipt_alg alg,
			kipt_keynr in_keynr,
			kipt_key **out_key) {
	//
	// Verify that the algorithm is usable
	if ((alg > _KIP_ALG_LAST) || (alg < 0)) {
		/* local algorithms <0 are incompatible*/
		errno = KIPERR_ALGORITHM_UNKNOWN;
		goto fail;
	} else if (_enctype_acceptance [alg] != 0) {
		errno = _enctype_acceptance [alg];
		goto fail;
	}
	assert (alg != _KIP_ALG_ANY);
	//
	// Find out how long the key store should be
	*out_key = NULL;
	krb5_error_code k5err = 0;
	size_t _keybytes = 0;
	size_t keylength = 0;
	k5err = krb5_c_keylengths (ctx->k5ctx, alg, &_keybytes, &keylength);
	if (k5err != 0) {
		errno = k5err;
		goto fail;
	}
	struct kip_key *newkey;
	newkey = calloc (1, sizeof (struct kip_key) + keylength);
	if (newkey == NULL) {
		errno = ENOMEM;
		goto fail;
	}
	//
	// Initialise, including an empty key block for krb5
	newkey->k5keyblk.magic    = KV5M_KEYBLOCK;
	newkey->k5keyblk.enctype  = alg;
	newkey->k5keyblk.contents = (krb5_octet *) &newkey[1];
	newkey->k5keyblk.length   = keylength;
	//
	// Construct a new keyid and set it -- ensure it is unique
	++ctx->uniqtr;
	if (ctx->uniqtr & 0x80000000) {
		/* out of range... say what?!? */
		errno = KIPERR_TOO_MANY_KEYS;
		goto fail;
	}
	newkey->keyid = (((kipt_keyid) ctx->uniqtr) << 32) | in_keynr;
	assert ((newkey->keyid & 0xffffffff) == in_keynr);
	assert ((newkey->keyid >> 32) == ctx->uniqtr);
	//
	// Initialise the hash algorithm built into each key
	if (!_hash_init (&newkey->keysum, newkey)) {
		/* We failed to initialise the hash -- error should repeat later */
		// errno = KIPERR_ALGORITHM_SUPPORT_TODO;
		// goto fail;
		// quietly ignore
	}
	//
	// Return successfully (still need to queue the key and sum!)
	*out_key = newkey;
	return true;
	//
	// Cleanup and fail
fail:
	return false;
}


static bool _addkey (kipt_ctx ctx, kipt_key *newkey) {
	//
	// Enqueue the key into the context
	LL_PREPEND (ctx->keys_head, newkey);
	//
	// Construct the default hash for this key
	newkey->keysum.sumid = newkey->keyid;
	LL_PREPEND (ctx->sums_head, &newkey->keysum);
	//
	// Return successfully
	return true;
}


/* Generate a KIP key.  There can be a few ways in which we
 * can get hold of the key; we do not define those yet but
 * ought to, at some point -- we need it for decryption.
 *
 * The input provides the key number as it will appear on
 * the wire.  The ideal situation is that this is unique,
 * but it is not required by KIP.  For use in the library,
 * we have stricter needs, so the context adds extra bits
 * to arrange this locally.
 *
 * The key identity is exported, but not the key itself.
 * As long as it resides in the context, the proper clearing
 * of the key material can be arranged by the KIP context.
 */
bool kipkey_generate (kipt_ctx ctx, kipt_alg alg,
			kipt_keynr   in_keynr,
			kipt_keyid *out_keyid) {
	//
	// Prepare the key by allocating and zeroing it
	kipt_key *tmpkey;
	if (!_newkey (ctx, alg, in_keynr, &tmpkey)) {
		goto fail;
	}
	//
	// Fill the key with random information
	krb5_error_code k5err = 0;
	k5err = krb5_c_make_random_key (ctx->k5ctx, alg, &tmpkey->k5keyblk);
	if (k5err != 0) {
		errno = k5err;
		goto free_fail;
	}
	if (!_addkey (ctx, tmpkey)) {
		goto free_fail;
	}
	//
	// Return successfully
	*out_keyid = tmpkey->keyid;
	return true;
	//
	// Cleanup and fail
free_fail:
	zap_free (tmpkey);
fail:
	return false;
}



/* KIP Service support is concealed in the KIP library.  The calls
 * kipkey_toservice() and kipkey_fromservice() serve to connect to the
 * KIP Service and export or import keys, where a server functions
 * as an authentication oracle with key dissimination according to
 * the occurrence of the authenticated identity in an ACL.
 *
 * Simply put, the KIP Service functions as a remote key map, and
 * the calls are very similar to the function pair kipkey_tomap()
 * and kipkey_frommap().
 *
 * The most influental place to specify the KIP Service domain is
 * in the KIP_REALM environment variable.  Lacking this, the realm
 * will be requested through getdomainname().  If that also yields
 * no result, the connection will not succeed.
 *
 * TODO: Not sure if we need to contact remote servers yet.
 *
 * TODO: Current naive protocol sends '?' or '!' plus raw data.
 */


#define HOSTNAME_BUFSIZE 256

#define CL_IN     1
#define RR_SRV   33
#define RR_A      1
#define RR_AAAA  28


typedef uint16_t net_uint16_t;
bool _dns2hostport (char *data, int datalen, char hostname [HOSTNAME_BUFSIZE], net_uint16_t *netport) {
	int hostofs = 0;
	char dataofs = 6;
	//
	// Harvest the port number as-is, that is, in network byte order
	if (datalen < 10) {
		/* Sillily small */
		return false;
	}
	* netport = * (uint16_t *) &data [4];
	//
	// Collect the labels of the host name
	while (data [dataofs] != 0) {
		unsigned int eltlen = data [dataofs];
		if (dataofs + eltlen + 1 > datalen) {
			return false;
		}
		if (hostofs + eltlen + 1 > HOSTNAME_BUFSIZE) {
			return false;
		}
		memcpy (hostname + hostofs, data + dataofs + 1, eltlen);
		hostname [hostofs + eltlen] = '.';
		hostofs += eltlen + 1;
		dataofs += eltlen + 1;
	}
	//
	// We should not return an empty string
	if (hostofs == 0) {
		return false;
	} else {
		hostname [hostofs-1] = 0;
		return true;
	}
}


static bool _send_to_kip_service (kipt_ctx ctx, uint8_t *data, size_t datalen) {
	//
	// See if we have a cached connection; if so, try to use it
	bool cached = true;
	if (ctx->service_uplink >= 0) {
		goto try_cached_uplink;
	}
flush_cache:
	cached = false;
	//
	// Construct the SRV query name
	char srvname [HOSTNAME_BUFSIZE];
	strcpy (srvname, "_kip._tcp.");
	int srvnamelen = strlen (srvname); 
	//
	// Find the desired KIP Service via SRV records under $KIP_REALM
	char *envrealm = getenv ("KIP_REALM");
	if (envrealm != NULL) {
		if (srvnamelen + strlen (envrealm) + 1 > sizeof (srvname)) {
			errno = KIPERR_INSANE_REQUEST;
			goto fail;
		}
		strcpy (srvname + srvnamelen, envrealm);
	} else if (getdomainname (srvname + srvnamelen, sizeof (srvname) - 1 - srvnamelen) != 0) {
		/* errno has been set */
		goto fail;
	}
	//
	// Open the Unbound library
	if (ctx->ubctx == NULL) {
		ctx->ubctx = ub_ctx_create ();
		if (ctx->ubctx != NULL) {
			// Load the /etc/hosts file, can be overridden with envvar UNBOUND_HOSTS
			ub_ctx_hosts (ctx->ubctx, getenv ("UNBOUND_HOSTS"));
		}
	}
	if (ctx->ubctx == NULL) {
		errno = KIPERR_SERVICE_NOTFOUND;
		goto fail;
	}
	//
	// Lookup the SRV record to find one or more host/port pairs
	struct ub_result *srv = NULL;
	if (ub_resolve (ctx->ubctx, srvname, RR_SRV, CL_IN, &srv) != 0) {
		errno = KIPERR_SERVICE_NOTFOUND;
		goto fail;
	}
	assert (srv != NULL);
	if ((!srv->havedata) || (srv->bogus) || (srv->nxdomain)) {
		/* TODO: Consider if we also need srv->secure */
		errno = KIPERR_SERVICE_NOTFOUND;
		goto srv_fail;
	}
	int iter_srv = -1;
	//
	// Find host name and port for each SRV record
	struct ub_result *aaaa = NULL;
	struct ub_result *a    = NULL;
another_srv:
	if (aaaa) {
		ub_resolve_free (aaaa);
		aaaa = NULL;
	}
	if (a) {
		ub_resolve_free (a);
		a = NULL;
	}
	iter_srv++;
	if (srv->data [iter_srv] == NULL) {
		errno = KIPERR_SERVICE_NOCONNECT;
		goto srv_fail;
	}
	net_uint16_t netport;
	char hostname [HOSTNAME_BUFSIZE];
	if (!_dns2hostport (srv->data [iter_srv], srv->len [iter_srv], hostname, &netport)) {
		goto another_srv;
	}
	//
	// Find the IP addresses for the host name in the SRV record
	if (ub_resolve (ctx->ubctx, hostname, RR_AAAA, CL_IN, &aaaa) != 0) {
		/* This should never fail */
		goto another_srv;
	}
	if (ub_resolve (ctx->ubctx, hostname, RR_A,    CL_IN, &a   ) != 0) {
		/* This should never fail */
		goto another_srv;
	}
	int iter_aaaa = -1;
	int iter_a    = -1;
	if ((!aaaa->nxdomain) && (!aaaa->bogus) && aaaa->havedata) {
		iter_aaaa = 0;
	}
	if ((!a   ->nxdomain) && (!a   ->bogus) && a   ->havedata) {
		iter_a    = 0;
	}
	//
	// Construct a socket address for IPv6 _or_ IPv4
	struct sockaddr_storage sa;
	socklen_t salen;
another_aaaa_a:
	if ((iter_aaaa >= 0) && (aaaa->data [iter_aaaa] != NULL)) {
		/* Copy IPv6 address and port, set salen, then increment iter_aaaa */
		         ((struct sockaddr_in6 *) &sa)->sin6_family = AF_INET6;
		memcpy (&((struct sockaddr_in6 *) &sa)->sin6_addr, aaaa->data [iter_aaaa], 16);
		         ((struct sockaddr_in6 *) &sa)->sin6_port = netport;
		salen = sizeof (struct sockaddr_in6);
		iter_aaaa++;
	} else if ((iter_a >= 0) && (a->data [iter_a] != NULL)) {
		/* Copy IPv4 address and port, set salen, then increment iter_a */
		         ((struct sockaddr_in *) &sa)->sin_family = AF_INET;
		memcpy (&((struct sockaddr_in *) &sa)->sin_addr, a->data [iter_a], 4);
		         ((struct sockaddr_in *) &sa)->sin_port = netport;
		salen = sizeof (struct sockaddr_in);
		iter_a++;
	} else {
		/* Iterators fell through, try another host:port */
		goto another_srv;
	}
	//
	// Connect to the KIP Service over TCP
	int sox = -1;
	sox = socket (sa.ss_family, SOCK_STREAM, 0);
	if (sox < 0) {
		goto another_aaaa_a;
	}
	if (connect (sox, (struct sockaddr *) &sa, salen) != 0) {
		close (sox);
		goto another_aaaa_a;
	}
	//
	// We are connected, and will no longer need our DNS handles
	ub_resolve_free (a);
	ub_resolve_free (aaaa);
	ub_resolve_free (srv);
	//
	// Cache our uplink to the KIP Service for later reuse attempts
	ctx->service_uplink = sox;
	//
	//TODO// Switch the TCP connection to TLS
	//
	// Send the prepared upstream data to the KIP Service
	ssize_t sent;
try_cached_uplink:
	sent = send (ctx->service_uplink, data, datalen, MSG_NOSIGNAL);
	if (sent < datalen) {
		if (cached) {
			close (ctx->service_uplink);
			ctx->service_uplink = -1;
			goto flush_cache;
		} else {
			errno = ECOMM;
			sent = -1;
		}
	}
	if (sent < 0) {
		/* errno has been set; close the uplink */
		close (ctx->service_uplink);
		ctx->service_uplink = -1;
		goto fail;
	}
	//
	// Cleanup and report success
	return true;
	//
	// Cleanup and report failure
a_srv_fail:
	ub_resolve_free (a);
aaaa_srv_fail:
	ub_resolve_free (aaaa);
srv_fail:
	ub_resolve_free (srv);
fail:
	return false;
}


static bool _recv_from_kip_service (kipt_ctx ctx, uint32_t max_datalen,
				uint8_t *out_data, uint32_t *out_datalen) {
	//
	// Assume we are connected because we just sent data
	assert (ctx->service_uplink >= 0);
	//
	// Read the desired data from the upstream
	ssize_t recvd = recv (ctx->service_uplink, out_data, (size_t) max_datalen, MSG_NOSIGNAL);
	//
	// Redirect a number of problems to errors
	if (recvd == 0) {
		errno = ECONNRESET;
		recvd = -1;
	} else if (recvd > max_datalen) {
		errno = ENOBUFS;
		recvd = -1;
	}
	//
	// Report any errors to the caller
	if (recvd < 0) {
		/* errno will have been set; shutdown the uplink */
		close (ctx->service_uplink);
		ctx->service_uplink = -1;
		goto fail;
	}
	//
	// Return successfully
	*out_datalen = recvd;
	return true;
	//
	// Cleanup and return error
fail:
	return false;
}


/* Add an acceptable KIP Service domain for a KIP key.  The
 * list will usually be limited to the various recipient's
 * domains and the domain of the sender (as a fallback).
 * Domains can be explicitly mentioned in future output, or
 * they can be left implicit when the context is clear enough.
 * For each domain, the white/black/gray lists of user name
 * patterns shall be supplied.  This ACL is specific for the
 * indicated domain's KIP Service.
 *
 * It is a good practice to trust a recipient's domain if
 * it declares a KIP Service.  It is the domains' prerogative
 * to define users, and its statements about users should be
 * trusted.  What needs to be verified is that acceptance
 * of a user identity does indeed come from the valid(ated)
 * domain for that user identity.
 *
 * As a result of this, the first attempt should always be
 * to ask a user's domain to provide KIP Service for its
 * users.  A second stage, used as backup or only for domains
 * without KIP Service, would be to send the key to the
 * sender domain's KIP Service.  You can define as many
 * KIP Services as you need for any of the keys.
 *
 * The output of this routine is "key mud", or the binary
 * unreadable content produced by the KIP Service and meant
 * to be returned upon later use.  This material is not
 * yours to allocate, because that might inconvenience the
 * protocol flow, but you must free() it when done.  If you
 * do want to control it, setup your own realloc() routine,
 * which is used to allocate and resize the structure.
 *
 * The hidden value contains only the single "keytohide" key,
 * but its identity is the wire format of a "keynr_t", so
 * upon retrieving it, it will be reachable by such hints.
 *
 * This function is likely to invoke the SASL callbacks that
 * you registered in the context, because it will have to
 * authenticate to the KIP Service.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_toservice (kipt_ctx ctx, kipt_keyid keytohide,
			//TODO// char *kip_service_domain,
			//TODO// bool explicit_domain,
			//TODO// char **whitelist,      /* ends in NULL */
			//TODO// char **blacklist,      /* ends in NULL */
			//TODO// char **graylist,       /* ends in NULL */
			uint32_t  max_keymudsz,
			uint8_t  *out_keymud,        /* outbuf */
			uint32_t *out_keymudsz) {    /* buflen */
	uint8_t keybuf [1024];
	uint32_t keybuflen;
	//
	// Find the key to send
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, keytohide);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	keybuflen = 8 + kk->k5keyblk.length;
	assert (keybuflen <= sizeof (keybuf));
	struct mappingpair { uint32_t kvno; int32_t enctype; };
	((struct mappingpair *) keybuf)->kvno    = htonl( (krb5_kvno) kk->keyid );	// Trim down to wire size
	((struct mappingpair *) keybuf)->enctype = htonl( kk->k5keyblk.enctype  );
	memcpy (keybuf+8, kk->k5keyblk.contents, kk->k5keyblk.length);
	//
	// Send the key -- TODO: and ACL -- TODO: packed in a DER protocol message
	uint8_t silly_command = '!';
	if (!_send_to_kip_service (ctx, &silly_command, 1)) {
		/* errno is already set */
		goto fail;
	}
	if (!_send_to_kip_service (ctx, keybuf, keybuflen)) {
		/* errno is already set */
		goto fail;
	}
	//
	// Receive the keymud back -- TODO: packed in a DER protocol message
	if (!_recv_from_kip_service (ctx, max_keymudsz, out_keymud, out_keymudsz)) {
		/* errno is already set */
		goto fail;
	}
	//
	// Return success
	return true;
	//
	// Cleanup and return failure
fail:
	return false;
}


/* Use a KIP service to extract a key that was hidden in "key mud"
 * by a previous call to kipkey_toservice().  Store the resulting
 * key in the KIP context and provide the customary locally unique
 * keyid for it.  The extension from the wire format of a keynr_t
 * into a handle of a keyid_t means that the latter could differ
 * from the keyid_t originally sent.  The key value is not exported.
 *
 * Provide the KIP Service domain to indicate where to try.  Upon
 * failure, a retry elsewhere may be called for.  Leave it to NULL
 * to use the explicitly mentioned service, if any.
 *
 * This function is likely to invoke the SASL callbacks that
 * you registered in the context, because it will have to
 * authenticate to the KIP Service.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_fromservice (kipt_ctx ctx,
			uint8_t *keymud, uint32_t keymudsz,
			//TODO// char *kip_service_domain,
			kipt_keyid *out_keyrevealed) {
	//
	// Send the keymud -- TODO: packed in a DER protocol message
	uint8_t silly_command = '?';
	if (!_send_to_kip_service (ctx, &silly_command, 1)) {
		/* errno is already set */
		goto fail;
	}
	if (!_send_to_kip_service (ctx, keymud, keymudsz)) {
		/* errno is already set */
		goto fail;
	}
	//
	// Receive the key back -- TODO: packed in a DER protocol message
	uint8_t keybuf [1024];
	uint32_t keybuflen;
	if (!_recv_from_kip_service (ctx, sizeof (keybuf), keybuf, &keybuflen)) {
		/* errno is already set */
		goto fail;
	}
	//
	// Verify the key data as it was received
	struct mappingpair { uint32_t kvno; int32_t enctype; };
	kipt_keynr keynr = ntohl( ((struct mappingpair *) keybuf)->kvno    );	// Trim down to wire size
	kipt_alg alg     = ntohl( ((struct mappingpair *) keybuf)->enctype );
	krb5_error_code k5err;
	size_t _keybytes = ~0;
	size_t keylength = ~0;
	k5err = krb5_c_keylengths (ctx->k5ctx, alg, &_keybytes, &keylength);
	if (keybuflen != 8+keylength) {
		errno = KIPERR_KEYMAP_SCRAMBLED;
		goto fail;
	}
	//
	// Prepare the key by allocating and zeroing it
	kipt_key *tmpkey;
	if (!_newkey (ctx, alg, keynr, &tmpkey)) {
		goto fail;
	}
	//
	// Fill the key material as it was received
	memcpy (tmpkey->k5keyblk.contents, keybuf+8, keylength);
	//
	// Insert the key block and its checksum into lists
	if (!_addkey (ctx, tmpkey)) {
		zap_free (tmpkey);
		goto fail;
	}
	//
	// Return success
	*out_keyrevealed = tmpkey->keyid;
	return true;
	//
	// Cleanup and return failure
fail:
	return false;
}


/* Produce a key mapping for a key.  This makes it possible to
 * have alternative paths, like a logical OR on the access
 * paths to a key and its contents.  To also provide an AND
 * compisition mechanism, it is possible to require the use
 * of multiple keys in a key mapping.  The result will be a
 * nested key mapping.
 *
 * The storage format for a nested key mapping is a header
 * with the mapping depth in 16 bits, (kvno,etype) pairs in
 * each 2x 32 bits, and then the nested encryption result
 * with encryption applied in the forward direction of the
 * list.  MACs and padding may pile up, but the out_keymudsz
 * will be set to represent all of the header and padding.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 *
 * If the keymudszmax is too low, this function sets
 * KIPERR_OUTPUT_SIZE and nothing will get written to keymud, not
 * even a NULL value would be noticed.  The out_keymudsz value
 * will be filled though, and you can use this to measure the
 * desired output size.  When you set keymudszmax=0 you can
 * trigger this deliberately.  (Note that out_keymudsz covers
 * all the mappings, even with depth above one.)
 */
bool kipkey_tomap (kipt_ctx ctx, kipt_keyid keyid_to_conceal,
			uint16_t    mappingdepth,                 /* AND count */
			kipt_keyid *mappingkeyids,                /* AND keyid */
			uint8_t *out_keymud, uint32_t max_keymudsz,  /* outbuf */
			uint32_t *out_keymudsz) {                    /* usedup */
	//
	// Sanity checks on mapping depth
	if (mappingdepth == 0) {
		errno = KIPERR_KEY_REQUIRED;
		return false;
	}
	if (mappingdepth > 100) {
		errno = KIPERR_INSANE_REQUEST;
		return false;
	}
	//
	// Allocate nesting keys on stack
	kipt_key *mappingkeys [mappingdepth];
	int i;
	for (i=0; i<mappingdepth; i++) {
		LL_SEARCH_SCALAR (ctx->keys_head, mappingkeys [i], keyid, mappingkeyids [i]);
		if (mappingkeys [i] == NULL) {
			errno = KIPERR_KEYID_NOT_FOUND;
			return false;
		}
	}
	//
	// Precompute the header size: depth, (kvno,enctp)+, (kvno,enctp)
	uint32_t hdrsz = 2 + 8 * mappingdepth + 8;
	//
	// Find the key to conceal, and its storage length
	kipt_key *kk_to_conceal = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk_to_conceal, keyid, keyid_to_conceal);
	if (kk_to_conceal == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		return false;
	}
	//
	// Precompute the size of the key to conceal
	krb5_error_code k5err;
	size_t _keybytes = ~0;
	size_t keylength = ~0;
	k5err = krb5_c_keylengths (ctx->k5ctx, kk_to_conceal->k5keyblk.enctype,
				&_keybytes, &keylength);
	if (k5err != 0) {
		errno = k5err;
		return false;
	}
	//
	// Compute the size of the nested-encrypted data
	size_t pre_len = keylength;
	size_t post_len = ~0;
	for (i=0; i<mappingdepth; i++) {
		kipt_alg mapalg = mappingkeys [i]->k5keyblk.enctype;
		k5err = krb5_c_encrypt_length (ctx->k5ctx, mapalg, pre_len, &post_len);
		if (k5err != 0) {
			errno = k5err;
			return false;
		}
		pre_len = post_len;
	}
	pre_len = keylength;	/* recover original */
	//
	// Check that we have enough space, warn otherwise
	*out_keymudsz = hdrsz + post_len;
	if (*out_keymudsz > max_keymudsz) {
		errno = KIPERR_OUTPUT_SIZE;
		return false;
	}
	//
	// Fill the header: depth#16, ( key#32, alg#32 )+, key#32, alg#32
	// No integrity checks, as the keys would fail on their MACs
	// (but the size of the final key should indeed be validated)
	* (uint16_t *) (out_keymud + 0) = htons( mappingdepth );
	for (i=0; i<mappingdepth; i++) {
		kipt_keynr mapkey = (uint32_t) mappingkeys [i]->keyid;
		kipt_alg   mapalg = mappingkeys [i]->k5keyblk.enctype;
		* (uint32_t *) (out_keymud + 2 + 8 * i) = htonl( mapkey );
		* ( int32_t *) (out_keymud + 6 + 8 * i) = htonl( mapalg );
	}
	* (uint32_t *) (out_keymud + 2 + 8 * i) = htonl( kk_to_conceal->keyid            );
	* ( int32_t *) (out_keymud + 6 + 8 * i) = htonl( kk_to_conceal->k5keyblk.enctype );
	//
	// Actually encrypt, with nesting, so rolling over itself...
	uint8_t tic [post_len];
	uint8_t toc [post_len];
	uint8_t *pre_data = kk_to_conceal->k5keyblk.contents;
	uint8_t *nxt_data = NULL;
	size_t cur_len = pre_len;
	for (i=0; i<mappingdepth; i++) {
		nxt_data = (pre_data != tic) ? tic : toc;
		krb5_data     plain;
		krb5_enc_data crypt;
		plain.data = pre_data;
		plain.length = cur_len;
		crypt.ciphertext.data = nxt_data;
		crypt.ciphertext.length = post_len;
		crypt.kvno    = (krb5_kvno) mappingkeys [i]->keyid;	/* cut down to wire size */
		crypt.enctype = mappingkeys [i]->k5keyblk.enctype;
		k5err = krb5_c_encrypt (ctx->k5ctx, &mappingkeys [i]->k5keyblk, KIP_KEYUSAGE_MAPPING,
				NULL, &plain, &crypt);
		if (k5err != 0) {
			errno = k5err;
			goto wipe_fail;
		}
		pre_data = nxt_data;
		cur_len = crypt.ciphertext.length;
	}
	assert (cur_len == post_len);
	//
	// Copy the result, then clear intermediate storage
	memcpy (out_keymud + hdrsz, nxt_data, post_len);
	memset (tic, 0, post_len);
	memset (toc, 0, post_len);
	//
	// Return successfully
	return true;
	//
	// Return failure
wipe_fail:
	memset (out_keymud, 0, max_keymudsz);
fail:
	return false;
}


/* Use already-known keys to extract a key that was hidden in "key
 * mud" by a previous call to kipkey_tomap().  Store the resulting
 * key in the KIP context and provide the customary locally unique
 * keyid for it.  The extension from the wire format of a keynr_t
 * into a handle of a keyid_t means that the latter could differ
 * from the keyid_t originally sent.  The key value is not exported.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_frommap (kipt_ctx ctx,
			uint8_t *keymud, uint32_t keymudsz,
			kipt_keyid *out_mappedkey) {
	struct mappingpair { uint32_t kvno; int32_t enctype; };
	//
	// Find mappingdepth, precompute headersize, point to pairs
	uint16_t mappingdepth = ntohs( * (uint16_t *) (keymud + 0) );
	uint32_t hdrsz = 2 + 8 * mappingdepth + 8;
	struct mappingpair *pairs = (void *) (keymud + 2);
	uint32_t pre_len = keymudsz - hdrsz;
	uint8_t *pre_ptr = keymud   + hdrsz;
	//
	// Sanity checks on mapping depth
	if (mappingdepth == 0) {
		errno = KIPERR_KEY_REQUIRED;
		return false;
	}
	if (mappingdepth > 100) {
		errno = KIPERR_INSANE_REQUEST;
		return false;
	}
	//
	// Start iteration over mappingpairs
	uint8_t tic [pre_len];
	uint8_t toc [pre_len];
	uint8_t *cur_data = pre_ptr;
	uint32_t cur_len  = pre_len;
	uint8_t *nxt_data = NULL;
	uint32_t nxt_len  = 0;
	int i = mappingdepth;
	while (i-- > 0) {
		krb5_kvno    cur_kvno = ntohl( pairs [i].kvno    );
		krb5_enctype cur_alg  = ntohl( pairs [i].enctype );
		nxt_data = (cur_data != tic) ? tic : toc;
		bool done = _loop_decrypt (ctx, KIP_KEYUSAGE_MAPPING,
				cur_kvno, cur_alg,
				NULL,
				cur_data, cur_len,
				nxt_data, &nxt_len);
		//
		// Complain if no usable key found
		if (!done) {
			errno = KIPERR_NO_MATCHING_KEY;
			goto wipe_fail;
		}
		//
		// Move on to the next stage
		cur_data = nxt_data;
		cur_len  = nxt_len;
	}
	//
	// Validate the length of the eventual key
	krb5_kvno tgt_kvno   = ntohl( pairs [mappingdepth].kvno    );
	krb5_enctype tgt_alg = ntohl( pairs [mappingdepth].enctype );
	size_t _keybytes = 0;
	size_t keylength = 0;
	krb5_error_code k5err = 0;
	k5err = krb5_c_keylengths (ctx->k5ctx, tgt_alg, &_keybytes, &keylength);
	if (k5err != 0) {
		errno = k5err;
		goto wipe_fail;
	}
	if (keylength != cur_len) {
		errno = KIPERR_KEYMAP_SCRAMBLED;
		goto wipe_fail;
	}
	//
	// Construct a new key block for the key
	kipt_key *tgt_key;
	if (!_newkey (ctx, tgt_alg, tgt_kvno, &tgt_key)) {
		goto wipe_fail;
	}
	memcpy (tgt_key->k5keyblk.contents, cur_data, keylength);
	memset (tic, 0, keymudsz - hdrsz);
	memset (toc, 0, keymudsz - hdrsz);
	//
	// Insert the key block and its checksum into lists
	if (!_addkey (ctx, tgt_key)) {
		zap_free (tgt_key);
		goto fail;
	}
	//
	// Return to report with success
	*out_mappedkey = tgt_key->keyid;
	return true;
	//
	// Return failure
wipe_fail:
	memset (tic, 0, keymudsz - hdrsz);
	memset (toc, 0, keymudsz - hdrsz);
fail:
	return false;
}



/* Integrity checks may be used to span independently encrypted
 * blocks.  Without these checks, it could be possible to remove
 * blocks, insert or duplicate older ones, or change the order
 * in which they occur.  This is generally undesirable, but it
 * is not a requirement for protocols employing single blocks.
 * 
 * These integrity checks are implemented as secure checksums
 * under protection of a key.  Only those who hold the key
 * could alter the document without breaking the checksum, so
 * that includes you when you can check it, but at least it
 * excludes anyone outside your trusted group.  Under symmetric
 * crypto, there is no difference between reading and writing
 * privileges, but there is a difference between the in-crowd
 * and the out-laws.
 *
 * There is a difference between integrity checks on encrypted
 * or decrypted content.  Note however, that a complex document
 * with sections encrypted to different keys may not be readable
 * in full by everyone.  Such unreadable content is best not
 * included in the integrity check, or it should be included
 * in its encrypted form.  Other applications may choose to
 * represent separate views on a document from each of the keys
 * used in it, since integrity checks are made with keys anyway.
 * This would mean that encrypted content is used where it
 * cannot be decrypted with the integrity-checking key, but use
 * decrypted content where it can be decrypted with that key.
 * This is all pretty wild, but there is room for diversity,
 * and that being a good thing we aim to support it here, while
 * leaving a simple-yet-secure case as a default.
 *
 * By default, every key starts its own checksum and will hash
 * everything that it decrypts.  You can additionally define
 * insertions; either with plain or muddy data, or perhaps you
 * feel a need to note where the checksummed blocks start and
 * end, as that is lost in the default approach.
 *
 * Checksums can be finished and exported at any time.  Their
 * value is a "muddy sum", ready to be inserted into a document
 * or other application flow.
 */



static bool _hash_init (kipt_sum *sum, kipt_key *key) {
	//
	// Extract data from the key; look it up later
	sum->keyalg = key->k5keyblk.enctype;
	sum->keyid  = key->keyid;
	//
	// Initialise the hash context
	switch (sum->keyalg) {
	case ENCTYPE_AES128_CTS_HMAC_SHA1_96:
	case ENCTYPE_AES256_CTS_HMAC_SHA1_96:
		return (SHA1_Init (&sum->hctx.sha1) == 1);
	case ENCTYPE_AES128_CTS_HMAC_SHA256_128:
		return (SHA256_Init (&sum->hctx.sha256) == 1);
	case ENCTYPE_AES256_CTS_HMAC_SHA384_192:
		return (SHA384_Init (&sum->hctx.sha384) == 1);
	case ENCTYPE_CAMELLIA128_CTS_CMAC:	/* TODO: Add support */
	case ENCTYPE_CAMELLIA256_CTS_CMAC:	/* TODO: Add support */
	default:
		return false;
	}
}


static bool _hash_update (kipt_sum *sum, uint8_t *data, uint32_t datalen) {
	switch (sum->keyalg) {
	case ENCTYPE_AES128_CTS_HMAC_SHA1_96:
	case ENCTYPE_AES256_CTS_HMAC_SHA1_96:
		return (SHA1_Update (&sum->hctx.sha1, data, datalen) == 1);
	case ENCTYPE_AES128_CTS_HMAC_SHA256_128:
		return (SHA256_Update (&sum->hctx.sha256, data, datalen) == 1);
	case ENCTYPE_AES256_CTS_HMAC_SHA384_192:
		return (SHA384_Update (&sum->hctx.sha384, data, datalen) == 1);
	case ENCTYPE_CAMELLIA128_CTS_CMAC:	/* TODO: Add support */
	case ENCTYPE_CAMELLIA256_CTS_CMAC:	/* TODO: Add support */
	default:
		return false;
	}
}


static uint16_t _hash_size (kipt_sum *sum) {
	switch (sum->keyalg) {
	case ENCTYPE_AES128_CTS_HMAC_SHA1_96:
	case ENCTYPE_AES256_CTS_HMAC_SHA1_96:
		return 20;
	case ENCTYPE_AES128_CTS_HMAC_SHA256_128:
		return 32;
	case ENCTYPE_AES256_CTS_HMAC_SHA384_192:
		return 48;
	case ENCTYPE_CAMELLIA128_CTS_CMAC:	/* TODO: Add support */
	case ENCTYPE_CAMELLIA256_CTS_CMAC:	/* TODO: Add support */
	default:
		return 0;
	}
}


static bool _hash_final (kipt_sum *sum, uint8_t *out_data) {
	/* assume out_data can hold _hash_size() bytes */
	switch (sum->keyalg) {
	case ENCTYPE_AES128_CTS_HMAC_SHA1_96:
	case ENCTYPE_AES256_CTS_HMAC_SHA1_96:
		return (SHA1_Final (out_data, &sum->hctx.sha1) == 1);
	case ENCTYPE_AES128_CTS_HMAC_SHA256_128:
		return (SHA256_Final (out_data, &sum->hctx.sha256) == 1);
	case ENCTYPE_AES256_CTS_HMAC_SHA384_192:
		return (SHA384_Final (out_data, &sum->hctx.sha384) == 1);
	case ENCTYPE_CAMELLIA128_CTS_CMAC:	/* TODO: Add support */
	case ENCTYPE_CAMELLIA256_CTS_CMAC:	/* TODO: Add support */
	default:
		return false;
	}
}


/* Start a new checksum, to be protected with the indicated
 * key identity.  This call is implicit for any key added to
 * the context; the kipt_keyid identity serves as the checksum
 * identity for this implied checksum; the reverse is not true.
 *
 * TODO: Does this make sense -- can applications use it, if
 * they have no way of setting the checksum identity?  Or is
 * perhaps something we should add here?
 */
bool kipsum_start (kipt_ctx ctx, kipt_keyid supporting_key,
			kipt_sumid *out_kipsum) {
	//
	// Find the key that supports this hash
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, supporting_key);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Allocate memory for the checksum
	kipt_sum *newsum = NULL;
	newsum = calloc (sizeof (kipt_sum), 1);
	if (newsum == NULL) {
		errno = ENOMEM;
		goto fail;
	}
	//
	// Initialise the hash
	_hash_init (newsum, kk);
	//
	// Find a new sumid value
	++ctx->uniqtr;
	if (ctx->uniqtr & 0x80000000) {
		/* out of range... say what?!? */
		errno = KIPERR_TOO_MANY_SUMS;
		goto fail;
	}
	newsum->sumid = 1 + ~ ctx->uniqtr;
	//
	// Enable future finding by sumid
	LL_PREPEND (ctx->sums_head, newsum);
	//
	// Report success
	*out_kipsum = newsum->sumid;
	return true;
	//
	// Report error after cleanup
zap_fail:
	zap_free (newsum);
fail:
	return false;
}


/* Update a checksum by inserting the bytes given into the
 * flow of hashed data.
 *
 * Note that a keyid is always a sumid; you can send data
 * to the checksum for your key by using its keyid in this
 * position.  Also note that this does not extend to
 * key numbers, as these are not sufficiently selective.
 */
bool kipsum_append (kipt_ctx ctx, kipt_sumid sumid_or_keyid,
			uint8_t *data, uint32_t datasz) {
	//
	// Find the checksum object
	kipt_sum *cs = NULL;
	LL_SEARCH_SCALAR (ctx->sums_head, cs, sumid, sumid_or_keyid);
	if (cs == NULL) {
		errno = KIPERR_SUMID_NOT_FOUND;
		goto fail;
	}
	//
	// Actually update the hash context
	if (!_hash_update (cs, data, datasz)) {
		errno = KIPERR_CHECKSUM_UPDATE;
		goto fail;
	}
	//
	// Return success
	return true;
	//
	// Return failure
fail:
	return false;
}


/* Sign a document: Export the checksum, which is a key-encrypted
 * form of the encryption type's mandatory hash.
 *
 * After success, this operation has consumed the checksum and it
 * cannot be used anymore.
 */
bool kipsum_sign (kipt_ctx ctx, kipt_sumid sumid_or_keyid, uint32_t max_siglen,
				uint32_t *out_siglen, uint8_t *out_sig) {
	//
	// Find the checksum object
	kipt_sum *cs = NULL;
	LL_SEARCH_SCALAR (ctx->sums_head, cs, sumid, sumid_or_keyid);
	if (cs == NULL) {
		errno = KIPERR_SUMID_NOT_FOUND;
		goto fail;
	}
	//
	// Find the supporting key object
	kipt_key *supkey = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, supkey, keyid, cs->keyid);
	if (supkey == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Find the length of the raw hash value
	uint16_t hashsz = _hash_size (cs);
	if (hashsz == 0) {
		errno = KIPERR_CHECKSUM_ALGORITHM;
		goto fail;
	}
	//
	// Determine if the size for encrypting the raw hash is available
	size_t needlen;
	krb5_error_code k5err;
	k5err = krb5_c_encrypt_length (ctx->k5ctx, supkey->k5keyblk.enctype, hashsz, &needlen);
	if (k5err != 0) {
		errno = k5err;
		goto fail;
	}
	if ((needlen >> 32) != 0) {
		errno = ERANGE;
		goto fail;
	}
	*out_siglen = (uint32_t) needlen;
	if (needlen > max_siglen) {
		errno = KIPERR_OUTPUT_SIZE;
		goto fail;
	}
	//
	// Determine the hash -- this should not fail anymore
	uint8_t rawhash [48];
	assert (hashsz <= sizeof (rawhash));
	assert (_hash_final (cs, rawhash));
	//
	// Encrypt the hash -- this should not fail anymore
	krb5_data     plain;
	krb5_enc_data crypt;
	plain.data   = rawhash;
	plain.length = hashsz;
	crypt.kvno    = (krb5_kvno) supkey->keyid;	/* cut down to wire size */
	crypt.enctype = supkey->k5keyblk.enctype;
	crypt.ciphertext.data   = out_sig;
	crypt.ciphertext.length = max_siglen;
	k5err = krb5_c_encrypt (ctx->k5ctx, &supkey->k5keyblk, KIP_KEYUSAGE_INTEGRITY,
			NULL, &plain, &crypt);
	//
	// Assure that encryption succeeded; the caller expects to reuse the hash on failure
	assert (k5err == 0);
	//
	// Report success
	return true;
	//
	// Report error after any cleanup
wipe_fail:
	memset (out_sig, 0, max_siglen);
fail:
	return false;
}


/* Verify a document: Compare the checksum, which was key-encrypted
 * with the encryption type's mandatory hash.
 *
 * After success, this operation has consumed the checksum and it
 * cannot be used anymore.  The checksum is also consumed if this
 * routine reports a failed checksum with KIPERR_CHECKSUM_INVALID.
 *
 * In general, those are the outcomes that you are looking for:
 *
 *  - true  for successful verifcation
 *  - false with errno=KIPERR_CHECKSUM_INVALID for signature failure
 *  - false with other errno for various operational problems
 */
bool kipsum_verify (kipt_ctx ctx, kipt_sumid sumid_or_keyid,
				uint32_t siglen, uint8_t *sig) {
	//
	// Find the checksum object
	kipt_sum *cs = NULL;
	LL_SEARCH_SCALAR (ctx->sums_head, cs, sumid, sumid_or_keyid);
	if (cs == NULL) {
		errno = KIPERR_SUMID_NOT_FOUND;
		goto fail;
	}
	//
	// Find the supporting key object
	kipt_key *supkey = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, supkey, keyid, cs->keyid);
	if (supkey == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Find the length of the raw hash value
	uint16_t hashsz = _hash_size (cs);
	if (hashsz == 0) {
		errno = KIPERR_CHECKSUM_ALGORITHM;
		goto fail;
	}
	//
	// Decrypt with the supporting key, and find a raw hash
	uint8_t sighash [48];
	assert (hashsz <= sizeof (sighash));
	krb5_error_code k5err = 0;
	krb5_enc_data crypt;
	krb5_data     plain;
	crypt.kvno    = (krb5_kvno) supkey->keyid;	/* Scale down to wire size */
	crypt.enctype = supkey->k5keyblk.enctype;
	crypt.ciphertext.data   = sig;
	crypt.ciphertext.length = siglen;
	plain.data   = sighash;
	plain.length = 48;
	k5err = krb5_c_decrypt (ctx->k5ctx, &supkey->k5keyblk,
			KIP_KEYUSAGE_INTEGRITY,
			NULL, &crypt, &plain);
	if (k5err != 0) {
		// Includes KRB5KRB_AP_ERR_BAD_INTEGRITY (useful info)
		errno = k5err;
		goto fail;
	}
	if (plain.length != hashsz) {
		errno = KIPERR_CHECKSUM_INVALID;
		goto fail;
	}
	//
	// Determine the hash from the context
	uint8_t rawhash [48];
	assert (hashsz <= sizeof (rawhash));
	assert (_hash_final (cs, rawhash));
	if (memcmp (sighash, rawhash, hashsz) != 0) {
		errno = KIPERR_CHECKSUM_INVALID;
		goto fail;
	}
	//
	// Report success
	return true;
	//
	// Reprt error after any cleanup
fail:
	return false;
}



/* Key Tables -- An extension to KIP for using key tables
 *
 * Key tables are used in Kerberos for storing fixed secrets, usually
 * for servers.  They are not used by clients since it would bind them
 * to the location of the keytab and because clients' credentials are
 * more difficult to protect than a server's.  This is why it is
 * probably a good idea to make libkiptab only available to servers.
 *
 * When used, the functionality consists of an extra call
 * kipkey_fromkeytab() that imports a given key from the
 * keytab.
 */



/* Load a KIP key from a key table.  If an opt_hostname is
 * given, the key should be named "kip/opt_hostname@DOMAIN"
 * and otherwise it will be a local name such as
 * "kip/MASTER@DOMAIN" for a master key.
 *
 * Whether the master key is accessible is not a matter of
 * hiding it from this API.  It is a matter of access
 * rights to the keytab containing it.  It is strongly
 * advisable to have "kip/MASTER@DOMAIN" on a keytab of
 * its own, and constrain access to that key.
 *
 * TODO: The opt_hostname has no use in the proper usecase
 *       of realm-centric use for KIP Service.  Or do we
 *       keep it for realm crossover between KIP Services?
 */
bool kipkey_fromkeytab (kipt_ctx ctx, char *opt_ktname,
			char *opt_hostname, char *domain,
			kipt_keynr kvno, kipt_alg enctype,
			kipt_keyid *out_keyid) {
#if 0
	//
	// Do not allow kvno or enctype to be zero
	assert (kvno != 0);
	assert (enctype != 0);
#endif
	//
#if 0
	//
	// Check that the opt_hostname, if mentioned, includes a dot
	if (strchr (opt_hostname, '.') == NULL) {
		/* Is this a good-enough error message? */
		errno = KIPERR_INSANE_REQUEST;
com_err ("libkip", errno, "Fault in %s:%d", __FILE__, __LINE__);
		return false;
	}
#endif
	//
	// Check the domain, map it to a realm "DOMAIN"
	assert (domain != NULL);
	int realmlen = strlen (domain);
	char realm [realmlen + 1];
	int i;
	for (i=0; i<realmlen; i++) {
		realm [i] = toupper (domain [i]);
	}
	realm [i] = '\0';
	//
	// Load the keytab
	krb5_error_code k5err;
	krb5_keytab kt;
	if (opt_ktname == NULL) {
		k5err = krb5_kt_default (ctx->k5ctx,             &kt);
	} else {
		k5err = krb5_kt_resolve (ctx->k5ctx, opt_ktname, &kt);
	}
	if (k5err != 0) {
		errno = k5err;
		goto fail;
	}
	//
	// Build the PrincipalName to lookup
	krb5_principal princ;
	if (opt_hostname != NULL) {
		k5err = krb5_build_principal (ctx->k5ctx, &princ,
				realmlen, realm, "kip", opt_hostname, NULL);
	} else {
		k5err = krb5_build_principal (ctx->k5ctx, &princ,
				realmlen, realm, "kip", "MASTER", NULL);
	}
	if (k5err != 0) {
		errno = k5err;
		goto kt_fail;
	}
	//
	// Load the keytab entry
	krb5_keytab_entry ktent;
	memset (&ktent, 0, sizeof (ktent));
	//TODO// k5err = krb5_kt_get_entry (ctx->k5ctx, kt, princ, kvno, enctype, &ktent);
	k5err = krb5_kt_get_entry (ctx->k5ctx, kt, princ, kvno, enctype, &ktent);
	if (k5err != 0) {
		errno = k5err;
		goto princ_kt_fail;
	}
	//
	// Setup a new key
	kipt_key *ktkey;
	if (!_newkey (ctx, ktent.key.enctype, ktent.vno, &ktkey)) {
		goto ent_princ_kt_fail;
	}
	if (ktent.key.length != ktkey->k5keyblk.length) {
		errno = EINVAL;
		goto ent_princ_kt_fail;
	}
	memcpy (ktkey->k5keyblk.contents, ktent.key.contents, ktent.key.length);
	if (!_addkey (ctx, ktkey)) {
		goto ent_princ_kt_fail;
	}
	//
	// Cleanup and return successfully
	krb5_free_keytab_entry_contents (ctx->k5ctx, &ktent);
	krb5_free_principal (ctx->k5ctx, princ);
	krb5_kt_close (ctx->k5ctx, kt);
	*out_keyid = ktkey->keyid;
	return true;
	//
	// Return failure
ent_princ_kt_fail:
	krb5_free_keytab_entry_contents (ctx->k5ctx, &ktent);
princ_kt_fail:
	krb5_free_principal (ctx->k5ctx, princ);
kt_fail:
	krb5_kt_close (ctx->k5ctx, kt);
fail:
	return false;
}


/* Internal function for KIP Service.
 *
 * Strip away the protective sheething of this KIP Service.
 *
 * This form reveals the protected data to be used in the KIP Service.
 * Part of this is the key in its internal format, which may be sent
 * to the client in this barren form, to be reconsituted to a key.
 *
 * Before this is done, TLS and SASL and the ACL should all have lined
 * up to a magic constellation that grants the permission to the user.
 *
 * Anyone may implement this function, but the trick is that everyone
 * will have their own key material and its related trust model.  The
 * KIP Service is a recognised entity through its mention in DNS.
 */
bool kipservice_strip (kipt_ctx ctx, kipt_keyid keyid,
				uint32_t cryptlen,     uint8_t *crypt,
				uint32_t max_plainlen, uint8_t *out_plain,
				uint32_t *out_plainlen) {
	//
	// Check if we have enough space for the output
	*out_plainlen = cryptlen;
	if (max_plainlen < cryptlen) {
		/* Too cautious, but how can we calc it? */
		errno = KIPERR_OUTPUT_SIZE;
		goto fail;
	}
	//
	//TODO// Retrieve kvno,enctype
	//
	// Find the key to use
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, keyid);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Decrypt the message remainder with the keyid from the keytab
	krb5_error_code k5err = 0;
	krb5_enc_data cryptdata;
	krb5_data     plaindata;
	cryptdata.kvno    = (krb5_kvno) keyid;	/* trim down to wire size */
	cryptdata.enctype = kk->k5keyblk.enctype;
	cryptdata.ciphertext.data   = crypt;
	cryptdata.ciphertext.length = cryptlen;
	plaindata.data   = out_plain;
	plaindata.length = max_plainlen;
	k5err = krb5_c_decrypt (ctx->k5ctx, &kk->k5keyblk,
			KIP_KEYUSAGE_SERVICE,
			NULL, &cryptdata, &plaindata);
	if (k5err != 0) {
		errno = k5err;
		goto zap_fail;
	}
	*out_plainlen = plaindata.length;
	//
	// Return success
	return true;
	//
	// Cleanup and return failure
zap_fail:
	memset (out_plain, 0, max_plainlen);	/* never ever leak */
fail:
	return false;
}


/* Internal function for KIP Service.
 *
 * Dress up a key and ACL by packing it into the protected data to be
 * used in the future in the KIP Service.
 *
 * The result is binary content and may be sent anywhere.  It will
 * only be stripped when the right party asks for it, and is acceptable
 * to the code that organised the dressup party in the first place.
 */
bool kipservice_dress (kipt_ctx ctx, kipt_keyid keyid,
				uint32_t plainlen,     uint8_t *plain,
				uint32_t max_cryptlen, uint8_t *out_crypt,
				uint32_t *out_cryptlen) {
	//
	// Find the key to use
	kipt_key *kk = NULL;
	LL_SEARCH_SCALAR (ctx->keys_head, kk, keyid, keyid);
	if (kk == NULL) {
		errno = KIPERR_KEYID_NOT_FOUND;
		goto fail;
	}
	//
	// Check if we have enough space for the output
	size_t needlen;
	krb5_error_code k5err;
	k5err = krb5_c_encrypt_length (ctx->k5ctx, kk->k5keyblk.enctype, plainlen, &needlen);
	if (max_cryptlen < needlen) {
		/* Too cautious, but how can we calc it? */
		errno = KIPERR_OUTPUT_SIZE;
		goto fail;
	}
	*out_cryptlen = needlen;
	//
	//TODO// Insert kvno,enctype
	//
	// Actually encrypt the information
	krb5_data     plaindata;
	krb5_enc_data cryptdata;
	plaindata.data   = plain;
	plaindata.length = plainlen;
	cryptdata.kvno    = (krb5_kvno) keyid;		/* trim down to wire size */
	cryptdata.enctype = kk->k5keyblk.enctype;
	cryptdata.ciphertext.data   = out_crypt;
	cryptdata.ciphertext.length = max_cryptlen;
	k5err = krb5_c_encrypt (ctx->k5ctx, &kk->k5keyblk,
			KIP_KEYUSAGE_SERVICE,
			NULL, &plaindata, &cryptdata);
	if (k5err != 0) {
		errno = k5err;
		goto zap_fail;
	}
	//
	// Return success
	return true;
	//
	// Cleanup and return failure
zap_fail:
	memset (out_crypt, 0, max_cryptlen);	/* never ever leak */
fail:
	return false;
}
