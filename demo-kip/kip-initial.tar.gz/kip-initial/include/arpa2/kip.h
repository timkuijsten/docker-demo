/* <arpa2/kip.h> -- The API to libkip keying and encryption.
 *
 * The KIP library performs encryption and decryption of data,
 * possibly with the help of an online KIP Service.  There is
 * a fair amount of luxoury, including key maps that enable very
 * powerful key derivation procedures.
 *
 * The cryptographic structures underpinning KIP is taken from
 * Kerberos.  This is not a common choice, but it is the result
 * of the kind of logic that we follow.  There is no need to
 * run a complete Kerberos infrastructure, to use these basic
 * algorithms and data formats.  Kerberos is helpful for its
 * own reasons, but not because of these underlying mechanistic
 * elements.  (Kerberos is useful for administrators as a
 * centralised identity management system, for users as a
 * single sign-on system servicing a plethora of protocols, and
 * to cryptographers as a system ready for Quantum Computers.)
 *
 * From: Rick van Rein <rick@openfortress.nl>
 */


#include <stdbool.h>
#include <stdint.h>



/* KIP algorithms are enctypes from Kerberos.  Note that these
 * are symmetric algorithms.  Their great disadvantage is that
 * we need to contact a KIP Service; their great benefit are
 * that they are proof from Quantum Computing.
 */
typedef int32_t kipt_alg;


/* KIP documents reference keys with a key number.  On the API,
 * this number is considered a mere hint at the key identity.
 * This is helpful when documents or streams of keys are being
 * merged.  Though this could open up an angle of attack, it
 * is easy to remedy that; key numbers can be random generated,
 * and probability theory will tell us what the chances of
 * abuse are for a given number of clashes from a given number
 * of inputs.  It should be relatively easy to separate deceit
 * from proper use of these facilities, and an error may be
 * be produced immediately at the time of document merges.
 * 
 * On the API, we have the luxoury of seeing everything pass
 * through.  That allows us to add bits to the key number and
 * form a key identity.  The extra bits cannot be sent on the
 * wire without repeating the problem; this is because those
 * extra bits are locally generated, and dynamic, but not of
 * impact on the remote key selection process.
 *
 * The API numbers are a superset of the wire numbers.  Inasfar
 * as the ranges overlap, API numbers refer to wire numbers,
 * including their property of being a hint.  Be careful with
 * this; not all API calls appreciate being dealt an upscaled
 * wire key hint as though it was unique.
 *
 * KIP wire format key numbers are stored in kvno field in the
 * Kerberos data formats.
 */
typedef uint32_t kipt_keynr;	/* for use on the wire */
typedef uint64_t kipt_keyid;	/* for use in the API */


/* Checksum identities are created automatically for every
 * key (and they actually have the same value as a keyid)
 * but it is possible to create extra checksums as well,
 * whose handles would of not be usable as keys.
 */
typedef uint64_t kipt_sumid;	/* includes all kipt_keyid */


/* The KIP context holds the keys and checksums as they
 * evolve during use of the API.  Anything connected to
 * the context will be cleaned up when it is destroyed.
 * keys will be zeroed before free()ing their memory,
 * and so will any checksums be.
 *
 * The KIP context is an opaque type.  Clients handle
 * a pointer only.
 */
struct kipt_context;
typedef struct kipt_context *kipt_ctx;


/* Key Usage values are used in Kerberos to allow the use of keys
 * for various purposes, without the risk that the result of one
 * operation could be meaningful to another.  Call it isolation
 * of key uses if you like.
 *
 * TODO: The codes below are allocated in the registry managed
 * by MIT for the krb5 software and its applications.
 */
#define KIP_KEYUSAGE_USERDATA	530
#define KIP_KEYUSAGE_MAPPING	531
#define KIP_KEYUSAGE_INTEGRITY	532
#define KIP_KEYUSAGE_SERVICE	533



/* Encrypt or *kip up* a clear text string into a bucket of mud.
 * The routine encrypts a block of clear text in isolation; your
 * application may however develop a system that splits content
 * into blocks of a moderate size and treat those separately.
 *
 * When your application splits data into blocks, the entirety
 * of the transported information is not protected by a sequence
 * of kipdata_up() calls.  The suggested remedy is to have an overall
 * checksum under protection of each key.  You can feed data into
 * the checksum with the routines below.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 *
 * If the max_mudsz is too low, this function sets KIPERR_OUTPUT_SIZE
 * and nothing will get written to mud, not even a NULL value would
 * be noticed.  The out_mudsz value will be filled, though, and you
 * can use this to measure the desired output size.  When you set
 * max_mudsz=0 you can trigger this deliberately.
 */
bool kipdata_up (kipt_ctx ctx, kipt_keyid key,
			uint8_t *clear,   uint32_t clearsz,    /* input  */
			uint8_t *out_mud, uint32_t max_mudsz,  /* outbuf */
			uint32_t *out_mudsz);                  /* usedup */


/* Decrypt or *kip down* a bucket of mud into a clear text string.
 * The routine decrypts a bucket of mud in isolation, and always
 * as a whole; the application may however compose multiple of
 * these buckets in some way.  See kipdata_up() for how this is done,
 * and be sure to validate the checksums it generates to retain
 * consistency.
 *
 * The key may be a unique key identity or the key number hints 
 * that form a subset thereof; hints may require a few passes
 * through the decryption process though, in case of clashes
 * of those key numbers.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 *
 * If the max_clearsz is too low, this function sets
 * KIPERR_OUTPUT_SIZE and nothing will get written to clean, not
 * even a NULL value would be noticed.  The out_clearsz value will
 * be filled though, and you can use this to measure the desired
 * output size.  When you set max_clearsz=0 you can trigger this
 * deliberately.
 */
bool kipdata_down (kipt_ctx ctx, kipt_keyid key,
			uint8_t *mud,       uint32_t mudsz,        /* input  */
			uint8_t *out_clear, uint32_t max_clearsz,  /* outbuf */
			uint32_t *out_clearsz);                    /* usedup */


/* Open a context for kipping up and/or down.  You can use different
 * contexts for the kip up and kip down processes.  The context is
 * a place in which to mount keys and checksums.  Once done, the
 * contents may be eradicated.
 */
bool kipctx_open (kipt_ctx *out_ctx);


/* Close a context for kip, destroying all the resources that were
 * allocated to it.  Any key material is first overwritten with
 * zeroes before it is removed.
 */
void kipctx_close (kipt_ctx ctx);


/* Produce random bytes with the given address and length.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.
 */
bool kipdata_random (kipt_ctx ctx, uint32_t len_target, uint8_t *out_target);


/* Given a KIP key, determine its algorithm.
 */
bool kipkey_algorithm (kipt_ctx ctx, kipt_keyid keyid,
			kipt_alg *out_alg);


/* Generate a KIP key.  There can be a few ways in which we
 * can get hold of the key; we do not define those yet but
 * ought to, at some point -- we need it for decryption.
 *
 * The input provides the key number as it will appear on
 * the wire.  The ideal situation is that this is unique,
 * but it is not required by KIP.  For use in the library,
 * we have stricter needs, so the context adds extra bits
 * to arrange this locally.
 *
 * The key identity is exported, but not the key itself.
 * As long as it resides in the context, the proper clearing
 * of the key material can be arranged by the KIP context.
 */
bool kipkey_generate (kipt_ctx ctx, kipt_alg alg,
			kipt_keynr   in_keynr,
			kipt_keyid *out_keyid);



/* KIP Service support is concealed in the KIP library.  The calls
 * kipkey_toservice() and kipkey_fromservice() serve to connect to the
 * KIP Service and export or import keys, where a server functions
 * as an authentication oracle with key dissimination according to
 * the occurrence of the authenticated identity in an ACL.
 *
 * Simply put, the KIP Service functions as a remote key map, and
 * the calls are very similar to the function pair kipkey_tomap()
 * and kipkey_frommap()
 *
 * The most influental place to specify the KIP Service domain is
 * in the KIP_REALM environment variable.  Lacking this, the realm
 * will be requested through getdomainname().  If that also yields
 * no result, the connection will not succeed.
 */


/* Add an acceptable KIP Service domain for a KIP key.  The
 * list will usually be limited to the various recipient's
 * domains and the domain of the sender (as a fallback).
 * Domains can be explicitly mentioned in future output, or
 * they can be left implicit when the context is clear enough.
 * For each domain, the white/black/gray lists of user name
 * patterns shall be supplied.  This ACL is specific for the
 * indicated domain's KIP Service.
 *
 * It is a good practice to trust a recipient's domain if
 * it declares a KIP Service.  It is the domains' prerogative
 * to define users, and its statements about users should be
 * trusted.  What needs to be verified is that acceptance
 * of a user identity does indeed come from the valid(ated)
 * domain for that user identity.
 *
 * As a result of this, the first attempt should always be
 * to ask a user's domain to provide KIP Service for its
 * users.  A second stage, used as backup or only for domains
 * without KIP Service, would be to send the key to the
 * sender domain's KIP Service.  You can define as many
 * KIP Services as you need for any of the keys.
 *
 * The output of this routine is "key mud", or the binary
 * unreadable content produced by the KIP Service and meant
 * to be returned upon later use.  This material is not
 * yours to allocate, because that might inconvenience the
 * protocol flow, but you must free() it when done.  If you
 * do want to control it, setup your own realloc() routine,
 * which is used to allocate and resize the structure.
 *
 * The hidden value contains only the single "keytohide" key,
 * but its identity is the wire format of a "keynr_t", so
 * upon retrieving it, it will be reachable by such hints.
 *
 * This function is likely to invoke the SASL callbacks that
 * you registered in the context, because it will have to
 * authenticate to the KIP Service.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_toservice (kipt_ctx ctx, kipt_keyid keytohide,
			//TODO// char *kip_service_domain,
			//TODO// bool explicit_domain,
			//TODO// char **whitelist,      /* ends in NULL */
			//TODO// char **blacklist,      /* ends in NULL */
			//TODO// char **graylist,       /* ends in NULL */
			uint32_t  max_keymudsz,
			uint8_t  *out_keymud,        /* outbuf */
			uint32_t *out_keymudsz);     /* buflen */


/* Use a KIP service to extract a key that was hidden in "key mud"
 * by a previous call to kipkey_toservice().  Store the resulting
 * key in the KIP context and provide the customary locally unique
 * keyid for it.  The extension from the wire format of a keynr_t
 * into a handle of a keyid_t means that the latter could differ
 * from the keyid_t originally sent.  The key value is not exported.
 *
 * Provide the KIP Service domain to indicate where to try.  Upon
 * failure, a retry elsewhere may be called for.  Leave it to NULL
 * to use the explicitly mentioned service, if any.
 *
 * This function is likely to invoke the SASL callbacks that
 * you registered in the context, because it will have to
 * authenticate to the KIP Service.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_fromservice (kipt_ctx ctx,
			uint8_t *keymud, uint32_t keymudsz,
			//TODO// char *kip_service_domain,
			kipt_keyid *out_keyrevealed);


/* Produce a key mapping for a key.  This makes it possible to
 * have alternative paths, like a logical OR on the access
 * paths to a key and its contents.  To also provide an AND
 * compisition mechanism, it is possible to require the use
 * of multiple keys in a key mapping.  The result will be a
 * nested key mapping.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 *
 * If the keymudszmax is too low, this function sets
 * KIPERR_OUTPUT_SIZE and nothing will get written to keymud, not
 * even a NULL value would be noticed.  The out_keymudsz value
 * will be filled though, and you can use this to measure the
 * desired output size.  When you set keymudszmax=0 you can
 * trigger this deliberately.  (Note that out_keymudsz covers
 * all the mappings, even with depth above one.)
 */
bool kipkey_tomap (kipt_ctx ctx, kipt_keyid keyid,
			uint16_t    mappingdepth,                 /* AND count */
			kipt_keyid *mappingkeyids,                /* AND keyid */
			uint8_t *out_keymud, uint32_t max_keymudsz,  /* outbuf */
			uint32_t *out_keymudsz);                     /* usedup */


/* Use already-known keys to extract a key that was hidden in "key
 * mud" by a previous call to kipkey_tomap().  Store the resulting
 * key in the KIP context and provide the customary locally unique
 * keyid for it.  The extension from the wire format of a keynr_t
 * into a handle of a keyid_t means that the latter could differ
 * from the keyid_t originally sent.  The key value is not exported.
 *
 * This function returns true on success, or false with errno set
 * on failure.  The errno values are enhanced with codes from the
 * com_err table "KIP" as defined in this package, and those in
 * use with Kerberos.  Among the KIP values may be ones that were
 * generated on the KIP Service.
 */
bool kipkey_frommap (kipt_ctx ctx,
			uint8_t *keymud, uint32_t keymudsz,
			kipt_keyid *out_mappedkey);


/* Integrity checks may be used to span independently encrypted
 * blocks.  Without these checks, it could be possible to remove
 * blocks, insert or duplicate older ones, or change the order
 * in which they occur.  This is generally undesirable, but it
 * is not a requirement for protocols employing single blocks.
 * 
 * These integrity checks are implemented as secure checksums
 * under protection of a key.  Only those who hold the key
 * could alter the document without breaking the checksum, so
 * that includes you when you can check it, but at least it
 * excludes anyone outside your trusted group.  Under symmetric
 * crypto, there is no difference between reading and writing
 * privileges, but there is a difference between the in-crowd
 * and the out-laws.
 *
 * There is a difference between integrity checks on encrypted
 * or decrypted content.  Note however, that a complex document
 * with sections encrypted to different keys may not be readable
 * in full by everyone.  Such unreadable content is best not
 * included in the integrity check, or it should be included
 * in its encrypted form.  Other applications may choose to
 * represent separate views on a document from each of the keys
 * used in it, since integrity checks are made with keys anyway.
 * This would mean that encrypted content is used where it
 * cannot be decrypted with the integrity-checking key, but use
 * decrypted content where it can be decrypted with that key.
 * This is all pretty wild, but there is room for diversity,
 * and that being a good thing we aim to support it here, while
 * leaving a simple-yet-secure case as a default.
 *
 * By default, every key starts its own checksum and will hash
 * everything that it decrypts.  You can additionally define
 * insertions; either with plain or muddy data, or perhaps you
 * feel a need to note where the checksummed blocks start and
 * end, as that is lost in the default approach.
 *
 * Checksums can be finished and exported at any time.  Their
 * value is a "muddy sum", ready to be inserted into a document
 * or other application flow.
 */


/* Start a new checksum, to be protected with the indicated
 * key identity.  This call is implicit for any key added to
 * the context; the kipt_keyid identity serves as the checksum
 * identity for this implied checksum; the reverse is not true.
 */
bool kipsum_start (kipt_ctx ctx, kipt_keyid supporting_key,
			kipt_sumid *out_kipsum);


/* Update a checksum by inserting the bytes given into the
 * flow of hashed data.
 *
 * Note that a keyid is always a sumid; you can send data
 * to the checksum for your key by using its keyid in this
 * position.  Also note that this does not extend to
 * key numbers, as these are not sufficiently selective.
 */
bool kipsum_append (kipt_ctx ctx, kipt_sumid sumid_or_keyid,
			uint8_t *data, uint32_t datasz);


/* Sign a document: Export the checksum, which is a key-encrypted
 * form of the encryption type's mandatory hash.
 *
 * After success, this operation has consumed the checksum and it
 * cannot be used anymore.
 */
bool kipsum_sign (kipt_ctx ctx, kipt_sumid sumid_or_keyid, uint32_t max_siglen,
				uint32_t *out_siglen, uint8_t *out_sig);


/* Verify a document: Compare the checksum, which was key-encrypted
 * with the encryption type's mandatory hash.
 *
 * After success, this operation has consumed the checksum and it
 * cannot be used anymore.  The checksum is also consumed if this
 * routine reports a failed checksum with KIPERR_CHECKSUM_INVALID.
 *
 * In general, those are the outcomes that you are looking for:
 *
 *  - true  for successful verifcation
 *  - false with errno=KIPERR_CHECKSUM_INVALID for signature failure
 *  - false with other errno for various operational problems
 */
bool kipsum_verify (kipt_ctx ctx, kipt_sumid sumid_or_keyid,
				uint32_t siglen, uint8_t *sig);



/* The KIP callbacks for SASL try to avoid enforcing local
 * preferences for identity management or SASL software.
 * You simply receive the SASL components exchanged with
 * the server, and you get to make the choices that make
 * sense in your library and your mechanism preference,
 * possibly even just a single mechanism.
 *
 * You need to implement a few functions kipsasl_xxx()
 * with your local SASL logic.  They will be given the
 * KIP context and a callback handle that you may
 * provide.
 *
 * A strongly advisable form is to use Kerberos, especially
 * GS2-KRB5-PLUS which has channel binding added.  We shall
 * provide you with tls-unique channel binding information.
 * We shall provide a library with kipsasl_xxx() functions
 * that you can use to do just this.
 *
 * If you don't have Kerberos yet, or simply have a craving
 * for entering a lot of passwords, your next good option
 * would be SCRAM-SHA256-PLUS or a variant with a higher
 * hash value.  Again, this can use the tls-unique channel
 * binding information that we shall provide.
 */



/* Initialiase a KIP SASL exchange.  This begins with the
 * selection of a mechanism from the list of options,
 * and makes a choice plus it returns an opaque handle
 * for further interactions.  It may also return a first
 * c2s byte sequence.
 *
 * The saslmechlist is separated by spaces, but it also
 * starts and ends with a space.  It is NUL-terminated.
 * Spaces will always be single spaces in this string.
 * You can easily use strstr() to find your favourite
 * mechanism with a space on each side.
 *
 * The out_mech is the number of the mechanism in the
 * list.  It is safe to count spaces, except for one,
 * preceding the selected mechanism.
 *
 * The inout_handle usually starts at NULL, but will be
 * recycled when kipsasl_pingpong() requests a switch of
 * mechanism through KS_REINITIALISE.  The handle will
 * be returned as NULL when no (new) selection of
 * mechanism was to the taste of the called routine.
 *
 * The out_c2sp will be set to NULL or to an initial
 * byte string.  If it is NULL, it indicates absense of
 * this message.  SASL distinguishes NULL from 0 length.
 */
extern bool kipsasl_initialise (kipt_ctx ctx, void *cbdata,
			char *chanbind_type,
			uint8_t *chanbind_data,
			uint16_t chanbind_sz,
			char *saslmechlist,   /* space-separated */
			uint16_t **out_mech,  /* index in list */
			void *inout_handle,
			uint8_t **out_c2sp, uint16_t *out_s2clen);


/* Make a single challenge/response exchange initialised
 * by the server and to which the client must respond.
 *
 * The s2c may be set to NULL or to a byte string.  If it
 * is set to NULL then it was not included in the message.
 * SASL distinguishes NULL from 0 length.
 *
 * The extra may be set to NULL or to a byte string, though
 * the latter is only permitted on successful completion.
 * If it is NULL then it was not included in the message.
 * SASL distinguishes NULL from 0 length.
 *
 * The out_c2sp will be set to NULL or to an initial
 * byte string.  If it is NULL, it indicates absense of
 * this message.  SASL distinguishes NULL from 0 length.
 *
 * The statusp will be filled with a status value, where:
 *  - KS_SUCCESS indicates a successful final result;
 *  - KS_FAILURE indicates a failed final result;
 *  - KS_CONTINUE indicates an intermediate result, more to do;
 *  - KS_REINITIALISE cuts off the current mechanism and asks
 *                    to call kipsasl_initialise() once more.
 *
 * The KS_SUCCESS and KS_FAILURE calls will cleanup the handle;
 * the other two need it to be sustained for later calls.
 */
enum kipsasl_status {
	KS_SUCCESS,
	KS_FAILURE,
	KS_CONTINUE,
	KS_REINITIALISE
};
extern bool kipsasl_chalresp (kipt_ctx ctx, void *handle,
			uint8_t *s2c, uint16_t s2csz,      /* challenge */
			uint8_t *extra, uint16_t extrasz,  /* extra or NULL */
			uint8_t **out_s2cp, uint16_t *out_s2clen,
			enum kipsasl_status *statusp);


/* Load a KIP key from a key table.  If an opt_hostname is
 * given, the key should be named "kip/opt_hostname@DOMAIN"
 * and otherwise it will be a local name such as
 * "kip/MASTER@DOMAIN" for a master key.
 *
 * Whether the master key is accessible is not a matter of
 * hiding it from this API.  It is a matter of access
 * rights to the keytab containing it.  It is strongly
 * advisable to have "kip/MASTER@DOMAIN" on a keytab of
 * its own, and constrain access to that key.
 *
 * Note: This functionality is separately linked; it is not
 *       part of the usualy libkip library.
 */
bool kipkey_fromkeytab (kipt_ctx ctx, char *opt_ktname,
			char *opt_hostname, char *domain,
			kipt_keynr kvno, kipt_alg enctype,
			kipt_keyid *out_keyid);


/* Internal function for KIP Service.
 *
 * Strip away the protective sheething of this KIP Service.
 *
 * This form reveals the protected data to be used in the KIP Service.
 * Part of this is the key in its internal format, which may be sent
 * to the client in this barren form, to be reconsituted to a key.
 *
 * Before this is done, TLS and SASL and the ACL should all have lined
 * up to a magic constellation that grants the permission to the user.
 *
 * Anyone may implement this function, but the trick is that everyone
 * will have their own key material and its related trust model.  The
 * KIP Service is a recognised entity through its mention in DNS.
 */
bool kipservice_strip (kipt_ctx ctx, kipt_keyid keyid,
				uint32_t cryptlen,     uint8_t *crypt,
				uint32_t max_plainlen, uint8_t *out_plain,
				uint32_t *out_plainlen);


/* Internal function for KIP Service.
 *
 * Dress up a key and ACL by packing it into the protected data to be
 * used in the future in the KIP Service.
 *
 * The result is binary content and may be sent anywhere.  It will
 * only be stripped when the right party asks for it, and is acceptable
 * to the code that organised the dressup party in the first place.
 */
bool kipservice_dress (kipt_ctx ctx, kipt_keyid keyid,
				uint32_t plainlen,     uint8_t *plain,
				uint32_t max_cryptlen, uint8_t *out_crypt,
				uint32_t *out_cryptlen);
